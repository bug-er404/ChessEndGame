/**
*  GlobalCounter.cpp
*  Implementation of GlobalCounter.hpp class.
*
*
*  Created by Salil D. Maharjan on 12/10/19.
*  Copyright © 2019 Salil Maharjan. All rights reserved.
*/

#include "GlobalCounter.hpp"

int g_whiteStateCounter = 0;
int g_blackStateCounter = 0;
